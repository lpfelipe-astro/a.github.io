
#include "vga.h"

extern "C" void kernel_main(void* multiboot_structure, unsigned int magic_number) {
    VGA::initialize();
    VGA::println("Welcome to TBCOS - Garage Build 0.1");
    VGA::print("> ");
    while (1) {}
}

namespace VGA {
    static const size_t VGA_WIDTH = 80;
    static const size_t VGA_HEIGHT = 25;
    uint16_t* terminal_buffer = (uint16_t*) 0xB8000;
    size_t terminal_row;
    size_t terminal_column;
    uint8_t terminal_color;

    uint8_t make_color(vga_color fg, vga_color bg) {
        return fg | bg << 4;
    }

    uint16_t make_vgaentry(char c, uint8_t color) {
        return (uint16_t)c | (uint16_t)color << 8;
    }

    void set_color(vga_color fg, vga_color bg) {
        terminal_color = make_color(fg, bg);
    }

    void put_char(char c) {
        if (c == '\n') {
            terminal_column = 0;
            if (++terminal_row == VGA_HEIGHT) terminal_row = 0;
            return;
        }
        const size_t index = terminal_row * VGA_WIDTH + terminal_column;
        terminal_buffer[index] = make_vgaentry(c, terminal_color);
        if (++terminal_column == VGA_WIDTH) {
            terminal_column = 0;
            if (++terminal_row == VGA_HEIGHT) terminal_row = 0;
        }
    }

    void print(const char* str) {
        for (size_t i = 0; str[i] != '\0'; i++) put_char(str[i]);
    }

    void println(const char* str) {
        print(str);
        put_char('\n');
    }

    void initialize() {
        terminal_row = 0;
        terminal_column = 0;
        set_color(VGA_COLOR_CYAN, VGA_COLOR_BLACK);
        for (size_t y = 0; y < VGA_HEIGHT; y++)
            for (size_t x = 0; x < VGA_WIDTH; x++)
                terminal_buffer[y * VGA_WIDTH + x] = make_vgaentry(' ', terminal_color);
    }
}
