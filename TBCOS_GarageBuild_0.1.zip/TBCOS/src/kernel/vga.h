
#pragma once
#include <stddef.h>
#include <stdint.h>

enum vga_color {
    VGA_COLOR_BLACK = 0,
    VGA_COLOR_CYAN = 3,
    VGA_COLOR_WHITE = 15,
};

namespace VGA {
    void initialize();
    void print(const char* str);
    void println(const char* str);
    void set_color(vga_color fg, vga_color bg);
}
